define({
  "_widgetLabel": "Naslov",
  "signin": "Prijavite se",
  "signout": "Odjava",
  "about": "Informacije",
  "signInTo": "Prijava u",
  "cantSignOutTip": "Funkcija nije dostupna u načinu pretpregleda."
});