define({
  "_widgetLabel": "Intestazione",
  "signin": "Accedi",
  "signout": "Disconnetti",
  "about": "Informazioni su",
  "signInTo": "Accedi a",
  "cantSignOutTip": "Questa funzione non è disponibile in modalità anteprima."
});