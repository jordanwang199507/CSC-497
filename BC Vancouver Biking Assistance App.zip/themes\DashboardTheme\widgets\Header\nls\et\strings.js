define({
  "_widgetLabel": "Päis",
  "signin": "Logi sisse",
  "signout": "Logi välja",
  "about": "Info",
  "signInTo": "Logi sisse",
  "cantSignOutTip": "See funktsioon pole eelvaaterežiimis rakendatav."
});