define({
  "_widgetLabel": "Koptekst",
  "signin": "Aanmelden",
  "signout": "Meld u af",
  "about": "Info",
  "signInTo": "Meld u aan bij",
  "cantSignOutTip": "Deze functie is niet beschikbaar in de voorbeeldmodus."
});