define({
  "_widgetLabel": "Zaglavlje",
  "signin": "Prijavite se",
  "signout": "Odjavite se",
  "about": "Osnovni podaci",
  "signInTo": "Prijavite se na",
  "cantSignOutTip": "Ova funkcija nije dostupna u režimu pregledanja."
});