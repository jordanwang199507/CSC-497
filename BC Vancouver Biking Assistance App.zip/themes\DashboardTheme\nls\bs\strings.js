define({
  "_themeLabel": "Tema nadzorne ploče",
  "_layout_default": "Zadani izgled",
  "_layout_right": "Pravi izgled"
});