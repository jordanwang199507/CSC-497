define({
  "_themeLabel": "Tema do Painel",
  "_layout_default": "Layout Padrão",
  "_layout_right": "Layout direito"
});