define({
  "_themeLabel": "Tema dashboard",
  "_layout_default": "Layout predefinito",
  "_layout_right": "Layout destra"
});