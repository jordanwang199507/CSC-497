define({
  "_themeLabel": "Tema nadzorne plošče",
  "_layout_default": "Privzeta postavitev",
  "_layout_right": "Desna postavitev"
});