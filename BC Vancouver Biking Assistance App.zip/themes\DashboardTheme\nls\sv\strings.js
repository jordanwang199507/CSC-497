define({
  "_themeLabel": "Tema för instrumentpanel",
  "_layout_default": "Standardlayout",
  "_layout_right": "Höger layout"
});