define({
  "_themeLabel": "Θέμα πίνακα εργαλείων",
  "_layout_default": "Προεπιλεγμένη διάταξη",
  "_layout_right": "Δεξιά διάταξη"
});