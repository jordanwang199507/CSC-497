define({
  "_themeLabel": "Töölaua teema",
  "_layout_default": "Vaikimisi paigutus",
  "_layout_right": "Parempoolne paigutus"
});