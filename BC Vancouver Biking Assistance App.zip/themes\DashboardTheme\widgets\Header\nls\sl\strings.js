define({
  "_widgetLabel": "Glava",
  "signin": "Prijava",
  "signout": "Odjava",
  "about": "Informacije",
  "signInTo": "Prijava v",
  "cantSignOutTip": "Ta funkcija v načinu predogleda ni na voljo."
});